document.addEventListener('DOMContentLoaded', function() {
    // Toggle Sidebar
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.admin-sidebar');
    const mainContent = document.querySelector('.admin-main');
    
    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('expanded');
    });
    
    // Mobile Sidebar Toggle
    function handleMobileSidebar() {
        if (window.innerWidth < 768) {
            sidebar.classList.remove('collapsed');
            sidebar.classList.add('show');
            document.body.style.overflow = 'hidden';
        } else {
            sidebar.classList.remove('show');
            document.body.style.overflow = '';
        }
    }
    
    window.addEventListener('resize', handleMobileSidebar);
    
    // Close mobile sidebar when clicking outside
    document.addEventListener('click', function(e) {
        if (window.innerWidth < 768 && !sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
            sidebar.classList.remove('show');
            document.body.style.overflow = '';
        }
    });
    
    // Initialize Charts
    const salesCtx = document.getElementById('salesChart').getContext('2d');
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    
    // Sales Chart
    const salesChart = new Chart(salesCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Sales',
                data: [65000, 59000, 80000, 81000, 56000, 55000, 40000, 75000, 82000, 91000, 89000, 95000],
                backgroundColor: 'rgba(192, 160, 128, 0.2)',
                borderColor: 'rgba(192, 160, 128, 1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        drawBorder: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
    
    // Revenue Chart
    const revenueChart = new Chart(revenueCtx, {
        type: 'doughnut',
        data: {
            labels: ['Men', 'Women', 'Accessories', 'Footwear'],
            datasets: [{
                data: [35, 40, 15, 10],
                backgroundColor: [
                    'rgba(192, 160, 128, 0.8)',
                    'rgba(0, 0, 0, 0.8)',
                    'rgba(214, 204, 194, 0.8)',
                    'rgba(150, 150, 150, 0.8)'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right'
                }
            },
            cutout: '70%'
        }
    });
    
    // Update charts when filter changes
    const chartFilter = document.querySelector('.chart-filter select');
    if (chartFilter) {
        chartFilter.addEventListener('change', function() {
            // In a real app, you would fetch new data based on the filter
            // For demo purposes, we'll just randomize the data
            const newData = salesChart.data.datasets[0].data.map(() => 
                Math.floor(Math.random() * 100000) + 20000
            );
            salesChart.data.datasets[0].data = newData;
            salesChart.update();
        });
    }
    
    // Form submissions
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            // In a real app, you would handle form submission here
            alert('Form submitted! In a real app, this would be sent to the server.');
        });
    });
});