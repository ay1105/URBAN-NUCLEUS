document.addEventListener('DOMContentLoaded', function() {
    // Filter functionality
    const filterButtons = document.querySelectorAll('.filter-btn');
    const collectionItems = document.querySelectorAll('.collection-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            const filterValue = this.getAttribute('data-filter');
            
            // Filter collections
            collectionItems.forEach(item => {
                if (filterValue === 'all') {
                    item.style.display = 'block';
                } else {
                    const categories = item.getAttribute('data-category').split(' ');
                    if (categories.includes(filterValue)) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                }
            });
        });
    });
    
    // Sort functionality
    const sortSelect = document.querySelector('.sort-select');
    const collectionsGrid = document.querySelector('.collections-grid');
    
    sortSelect.addEventListener('change', function() {
        const sortValue = this.value;
        const items = Array.from(collectionItems);
        
        items.sort((a, b) => {
            // In a real implementation, you would sort based on actual data
            // This is just a placeholder for the sorting logic
            if (sortValue === 'newest') {
                return 0; // Would compare dates in real implementation
            } else if (sortValue === 'price-low') {
                return 0; // Would compare prices in real implementation
            } else if (sortValue === 'price-high') {
                return 0; // Would compare prices in real implementation
            } else {
                return 0; // Default (featured)
            }
        });
        
        // Re-append sorted items
        items.forEach(item => {
            collectionsGrid.appendChild(item);
        });
    });
    
    // Load more functionality
    const loadMoreBtn = document.querySelector('.load-more button');
    let visibleItems = 6; // Initial number of visible items
    
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            // In a real implementation, this would load more items from an API
            // For demo purposes, we'll just show a message
            alert('Loading more collections...');
            
            // You would typically:
            // 1. Make an AJAX request to get more items
            // 2. Append new items to the grid
            // 3. Hide the button if no more items exist
        });
    }
    
    // Check URL for filter parameter
    const urlParams = new URLSearchParams(window.location.search);
    const filterParam = urlParams.get('filter');
    
    if (filterParam) {
        // Find and click the corresponding filter button
        const matchingButton = Array.from(filterButtons).find(btn => 
            btn.getAttribute('data-filter') === filterParam
        );
        
        if (matchingButton) {
            matchingButton.click();
        }
    }
});