document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenuClose = document.querySelector('.mobile-menu-close');
    const mobileMenu = document.querySelector('.mobile-menu');
    
    mobileMenuBtn.addEventListener('click', function() {
        mobileMenu.classList.add('active');
        document.body.style.overflow = 'hidden';
    });
    
    mobileMenuClose.addEventListener('click', function() {
        mobileMenu.classList.remove('active');
        document.body.style.overflow = '';
    });
    
    // Hero Slider
    const heroSlides = document.querySelectorAll('.hero-slide');
    const prevSlideBtn = document.querySelector('.prev-slide');
    const nextSlideBtn = document.querySelector('.next-slide');
    let currentSlide = 0;
    
    function showSlide(index) {
        heroSlides.forEach(slide => slide.classList.remove('active'));
        heroSlides[index].classList.add('active');
        currentSlide = index;
    }
    
    function nextSlide() {
        let nextIndex = (currentSlide + 1) % heroSlides.length;
        showSlide(nextIndex);
    }
    
    function prevSlide() {
        let prevIndex = (currentSlide - 1 + heroSlides.length) % heroSlides.length;
        showSlide(prevIndex);
    }
    
    nextSlideBtn.addEventListener('click', nextSlide);
    prevSlideBtn.addEventListener('click', prevSlide);
    
    // Auto slide change every 5 seconds
    setInterval(nextSlide, 5000);
    
    // Quick View Modal
    const quickViewBtns = document.querySelectorAll('.quick-view');
    const quickViewModal = document.querySelector('.quick-view-modal');
    const quickViewClose = document.querySelector('.quick-view-close');
    const quickViewOverlay = document.querySelector('.quick-view-modal-overlay');
    const quickViewContent = document.querySelector('.quick-view-product');
    
    // Sample product data - in a real app, this would come from an API
    const products = {
        1: {
            id: 1,
            name: "Silk Evening Gown",
            price: "₹12,999",
            description: "A luxurious silk evening gown with intricate detailing and a flowing silhouette. Perfect for special occasions and black-tie events.",
            details: "100% Pure Silk | Handcrafted | Available in Black, Beige, and Burgundy",
            images: [
                "images/product-1.jpg",
                "images/product-1-alt1.jpg",
                "images/product-1-alt2.jpg"
            ],
            colors: ["#000000", "#c0a080", "#800020"],
            sizes: ["XS", "S", "M", "L", "XL"]
        },
        2: {
            id: 2,
            name: "Linen Tailored Blazer",
            price: "₹9,999",
            description: "A perfectly tailored linen blazer that combines comfort with sophistication. Ideal for both professional and casual settings.",
            details: "100% Premium Linen | Unlined Construction | Available in Charcoal and Natural",
            images: [
                "images/product-2.jpg",
                "images/product-2-alt1.jpg",
                "images/product-2-alt2.jpg"
            ],
            colors: ["#3a3a3a", "#e8d8c0"],
            sizes: ["S", "M", "L", "XL"]
        },
        3: {
            id: 3,
            name: "Cashmere Sweater",
            price: "₹8,499",
            description: "Ultra-soft cashmere sweater with a relaxed fit. Provides exceptional warmth without bulk.",
            details: "100% Mongolian Cashmere | Lightweight | Available in Ivory, Charcoal, and Wine",
            images: [
                "images/product-3.jpg",
                "images/product-3-alt1.jpg",
                "images/product-3-alt2.jpg"
            ],
            colors: ["#f0e0d0", "#505050", "#a03030"],
            sizes: ["XS", "S", "M", "L"]
        },
        4: {
            id: 4,
            name: "Leather Crossbody Bag",
            price: "₹15,999",
            description: "Handcrafted leather crossbody bag with premium hardware. Features multiple compartments for organization.",
            details: "Full-grain Italian Leather | Gold-tone Hardware | Available in Black and Tan",
            images: [
                "images/product-4.jpg",
                "images/product-4-alt1.jpg",
                "images/product-4-alt2.jpg"
            ],
            colors: ["#1a1a1a", "#c0a080"],
            sizes: ["One Size"]
        }
    };
    
    quickViewBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = this.getAttribute('data-id');
            const product = products[productId];
            
            if (product) {
                quickViewContent.innerHTML = `
                    <div class="quick-view-images">
                        <div class="main-image">
                            <img src="${product.images[0]}" alt="${product.name}">
                        </div>
                        <div class="thumbnail-images">
                            ${product.images.map(img => `
                                <img src="${img}" alt="${product.name}">
                            `).join('')}
                        </div>
                    </div>
                    <div class="quick-view-details">
                        <h2>${product.name}</h2>
                        <p class="price">${product.price}</p>
                        <div class="description">
                            <p>${product.description}</p>
                            <p>${product.details}</p>
                        </div>
                        <div class="color-options">
                            <h4>Color</h4>
                            <div class="colors">
                                ${product.colors.map(color => `
                                    <span class="color-option" style="background-color: ${color};"></span>
                                `).join('')}
                            </div>
                        </div>
                        <div class="size-options">
                            <h4>Size</h4>
                            <select class="size-select">
                                ${product.sizes.map(size => `
                                    <option value="${size}">${size}</option>
                                `).join('')}
                            </select>
                        </div>
                        <div class="quantity">
                            <h4>Quantity</h4>
                            <div class="quantity-selector">
                                <button class="quantity-minus">-</button>
                                <input type="number" value="1" min="1">
                                <button class="quantity-plus">+</button>
                            </div>
                        </div>
                        <button class="btn btn-dark add-to-cart" data-id="${product.id}">Add to Cart</button>
                    </div>
                `;
                
                quickViewModal.classList.add('active');
                document.body.style.overflow = 'hidden';
                
                // Add event listeners for the new elements
                const thumbnails = quickViewContent.querySelectorAll('.thumbnail-images img');
                const mainImage = quickViewContent.querySelector('.main-image img');
                
                thumbnails.forEach(thumb => {
                    thumb.addEventListener('click', function() {
                        mainImage.src = this.src;
                    });
                });
                
                const minusBtn = quickViewContent.querySelector('.quantity-minus');
                const plusBtn = quickViewContent.querySelector('.quantity-plus');
                const quantityInput = quickViewContent.querySelector('.quantity input');
                
                minusBtn.addEventListener('click', function() {
                    let value = parseInt(quantityInput.value);
                    if (value > 1) {
                        quantityInput.value = value - 1;
                    }
                });
                
                plusBtn.addEventListener('click', function() {
                    let value = parseInt(quantityInput.value);
                    quantityInput.value = value + 1;
                });
            }
        });
    });
    
    quickViewClose.addEventListener('click', closeQuickView);
    quickViewOverlay.addEventListener('click', closeQuickView);
    
    function closeQuickView() {
        quickViewModal.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    // Wishlist
    const wishlistBtns = document.querySelectorAll('.add-to-wishlist');
    
    wishlistBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            this.innerHTML = '<i class="fas fa-heart"></i>';
            this.style.color = '#ff0000';
        });
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
});

// main.js - Home Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // ========== MOBILE MENU TOGGLE ==========
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenuClose = document.querySelector('.mobile-menu-close');
    const mobileMenu = document.querySelector('.mobile-menu');
    
    mobileMenuBtn.addEventListener('click', function() {
        mobileMenu.classList.add('active');
        document.body.style.overflow = 'hidden';
    });
    
    mobileMenuClose.addEventListener('click', function() {
        mobileMenu.classList.remove('active');
        document.body.style.overflow = '';
    });

    // ========== HERO SLIDER ==========
    const heroSlides = document.querySelectorAll('.hero-slide');
    const prevSlideBtn = document.querySelector('.prev-slide');
    const nextSlideBtn = document.querySelector('.next-slide');
    let currentSlide = 0;
    let slideInterval;
    
    function showSlide(index) {
        heroSlides.forEach(slide => slide.classList.remove('active'));
        heroSlides[index].classList.add('active');
        currentSlide = index;
    }
    
    function nextSlide() {
        let nextIndex = (currentSlide + 1) % heroSlides.length;
        showSlide(nextIndex);
    }
    
    function prevSlide() {
        let prevIndex = (currentSlide - 1 + heroSlides.length) % heroSlides.length;
        showSlide(prevIndex);
    }
    
    nextSlideBtn.addEventListener('click', function() {
        nextSlide();
        resetSlideInterval();
    });
    
    prevSlideBtn.addEventListener('click', function() {
        prevSlide();
        resetSlideInterval();
    });
    
    function startSlideInterval() {
        slideInterval = setInterval(nextSlide, 5000);
    }
    
    function resetSlideInterval() {
        clearInterval(slideInterval);
        startSlideInterval();
    }
    
    // Initialize slider
    if (heroSlides.length > 0) {
        showSlide(0);
        startSlideInterval();
        
        // Pause on hover
        const heroSlider = document.querySelector('.hero-slider');
        heroSlider.addEventListener('mouseenter', () => clearInterval(slideInterval));
        heroSlider.addEventListener('mouseleave', startSlideInterval);
    }

    // ========== QUICK VIEW MODAL ==========
    const quickViewBtns = document.querySelectorAll('.quick-view');
    const quickViewModal = document.querySelector('.quick-view-modal');
    const quickViewClose = document.querySelector('.quick-view-close');
    const quickViewOverlay = document.querySelector('.quick-view-modal-overlay');
    const quickViewContent = document.querySelector('.quick-view-product');
    
    // Sample product data (in a real app, this would come from an API)
    const products = {
        1: {
            id: 1,
            name: "Silk Evening Gown",
            price: "₹12,999",
            description: "A luxurious silk evening gown with intricate detailing and a flowing silhouette. Perfect for special occasions and black-tie events.",
            details: "100% Pure Silk | Handcrafted | Available in Black, Beige, and Burgundy",
            images: [
                "images/product-1.jpg",
                "images/product-1-alt1.jpg",
                "images/product-1-alt2.jpg"
            ],
            colors: ["#000000", "#c0a080", "#800020"],
            sizes: ["XS", "S", "M", "L", "XL"]
        },
        2: {
            id: 2,
            name: "Linen Tailored Blazer",
            price: "₹9,999",
            description: "A perfectly tailored linen blazer that combines comfort with sophistication. Ideal for both professional and casual settings.",
            details: "100% Premium Linen | Unlined Construction | Available in Charcoal and Natural",
            images: [
                "images/product-2.jpg",
                "images/product-2-alt1.jpg",
                "images/product-2-alt2.jpg"
            ],
            colors: ["#3a3a3a", "#e8d8c0"],
            sizes: ["S", "M", "L", "XL"]
        },
        3: {
            id: 3,
            name: "Cashmere Sweater",
            price: "₹8,499",
            description: "Ultra-soft cashmere sweater with a relaxed fit. Provides exceptional warmth without bulk.",
            details: "100% Mongolian Cashmere | Lightweight | Available in Ivory, Charcoal, and Wine",
            images: [
                "images/product-3.jpg",
                "images/product-3-alt1.jpg",
                "images/product-3-alt2.jpg"
            ],
            colors: ["#f0e0d0", "#505050", "#a03030"],
            sizes: ["XS", "S", "M", "L"]
        },
        4: {
            id: 4,
            name: "Leather Crossbody Bag",
            price: "₹15,999",
            description: "Handcrafted leather crossbody bag with premium hardware. Features multiple compartments for organization.",
            details: "Full-grain Italian Leather | Gold-tone Hardware | Available in Black and Tan",
            images: [
                "images/product-4.jpg",
                "images/product-4-alt1.jpg",
                "images/product-4-alt2.jpg"
            ],
            colors: ["#1a1a1a", "#c0a080"],
            sizes: ["One Size"]
        }
    };
    
    quickViewBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = this.getAttribute('data-id');
            const product = products[productId];
            
            if (product) {
                quickViewContent.innerHTML = `
                    <div class="quick-view-images">
                        <div class="main-image">
                            <img src="${product.images[0]}" alt="${product.name}">
                        </div>
                        <div class="thumbnail-images">
                            ${product.images.map(img => `
                                <img src="${img}" alt="${product.name}">
                            `).join('')}
                        </div>
                    </div>
                    <div class="quick-view-details">
                        <h2>${product.name}</h2>
                        <p class="price">${product.price}</p>
                        <div class="description">
                            <p>${product.description}</p>
                            <p>${product.details}</p>
                        </div>
                        <div class="color-options">
                            <h4>Color</h4>
                            <div class="colors">
                                ${product.colors.map(color => `
                                    <span class="color-option" style="background-color: ${color};"></span>
                                `).join('')}
                            </div>
                        </div>
                        <div class="size-options">
                            <h4>Size</h4>
                            <select class="size-select">
                                ${product.sizes.map(size => `
                                    <option value="${size}">${size}</option>
                                `).join('')}
                            </select>
                        </div>
                        <div class="quantity">
                            <h4>Quantity</h4>
                            <div class="quantity-selector">
                                <button class="quantity-minus">-</button>
                                <input type="number" value="1" min="1">
                                <button class="quantity-plus">+</button>
                            </div>
                        </div>
                        <button class="btn btn-dark add-to-cart" data-id="${product.id}">Add to Cart</button>
                    </div>
                `;
                
                quickViewModal.classList.add('active');
                document.body.style.overflow = 'hidden';
                
                // Add event listeners for the new elements
                const thumbnails = quickViewContent.querySelectorAll('.thumbnail-images img');
                const mainImage = quickViewContent.querySelector('.main-image img');
                
                thumbnails.forEach(thumb => {
                    thumb.addEventListener('click', function() {
                        mainImage.src = this.src;
                    });
                });
                
                const minusBtn = quickViewContent.querySelector('.quantity-minus');
                const plusBtn = quickViewContent.querySelector('.quantity-plus');
                const quantityInput = quickViewContent.querySelector('.quantity input');
                
                minusBtn.addEventListener('click', function() {
                    let value = parseInt(quantityInput.value);
                    if (value > 1) {
                        quantityInput.value = value - 1;
                    }
                });
                
                plusBtn.addEventListener('click', function() {
                    let value = parseInt(quantityInput.value);
                    quantityInput.value = value + 1;
                });
            }
        });
    });
    
    quickViewClose.addEventListener('click', closeQuickView);
    quickViewOverlay.addEventListener('click', closeQuickView);
    
    function closeQuickView() {
        quickViewModal.classList.remove('active');
        document.body.style.overflow = '';
    }

    // ========== WISHLIST FUNCTIONALITY ==========
    const wishlistBtns = document.querySelectorAll('.add-to-wishlist');
    
    wishlistBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const productCard = this.closest('.product-card');
            const productId = productCard.querySelector('.quick-view').getAttribute('data-id');
            
            this.innerHTML = '<i class="fas fa-heart"></i>';
            this.style.color = '#ff0000';
            
            // In a real app, you would add to wishlist here
            addToWishlist(productId);
        });
    });
    
    function addToWishlist(productId) {
        // This would typically call an API or update localStorage
        console.log(`Added product ${productId} to wishlist`);
    }

    // ========== SMOOTH SCROLLING ==========
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });

    // ========== NEWSLETTER FORM ==========
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const emailInput = this.querySelector('input[type="email"]');
            const email = emailInput.value.trim();
            
            if (validateEmail(email)) {
                // In a real app, you would submit to your backend
                console.log('Subscribing email:', email);
                alert('Thank you for subscribing!');
                emailInput.value = '';
            } else {
                alert('Please enter a valid email address');
            }
        });
    }
    
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    // ========== PRODUCT HOVER EFFECTS ==========
    const productCards = document.querySelectorAll('.product-card');
    
    productCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            const img = this.querySelector('.product-image img');
            img.style.transform = 'scale(1.05)';
            
            const actions = this.querySelector('.product-actions');
            actions.style.opacity = '1';
        });
        
        card.addEventListener('mouseleave', function() {
            const img = this.querySelector('.product-image img');
            img.style.transform = 'scale(1)';
            
            const actions = this.querySelector('.product-actions');
            actions.style.opacity = '0';
        });
    });

    // ========== INSTAGRAM HOVER EFFECTS ==========
    const instagramItems = document.querySelectorAll('.instagram-item');
    
    instagramItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            const overlay = this.querySelector('.instagram-overlay');
            overlay.style.opacity = '1';
        });
        
        item.addEventListener('mouseleave', function() {
            const overlay = this.querySelector('.instagram-overlay');
            overlay.style.opacity = '0';
        });
    });
});

// Add to cart functionality
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const productId = this.getAttribute('data-id');
        // Here you would normally make an AJAX call to add to cart
        // For now, we'll just update the cart count
        const cartCount = document.querySelector('.cart-count');
        let count = parseInt(cartCount.textContent) + 1;
        cartCount.textContent = count;
        
        // Optional: Show a confirmation message
        alert('Item added to your shopping bag');
    });
});