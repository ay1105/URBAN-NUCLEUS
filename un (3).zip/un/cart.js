 // Cart functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Quantity controls
            const quantityBtns = document.querySelectorAll('.quantity-btn');
            quantityBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const input = this.parentElement.querySelector('.quantity-input');
                    let value = parseInt(input.value);
                    
                    if (this.textContent === '+' && value < 10) {
                        input.value = value + 1;
                    } else if (this.textContent === '-' && value > 1) {
                        input.value = value - 1;
                    }
                    
                    // Here you would update cart totals via AJAX
                });
            });
            
            // Remove items
            const removeBtns = document.querySelectorAll('.remove-item');
            removeBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    // Here you would remove the item via AJAX
                    this.closest('.cart-item').remove();
                    // Update cart count in header
                    updateCartCount(-1);
                });
            });
            
            function updateCartCount(change) {
                const cartCount = document.querySelector('.cart-count');
                let count = parseInt(cartCount.textContent) + change;
                cartCount.textContent = count > 0 ? count : 0;
            }
        });

        // Handle checkout button click
document.querySelector('.checkout-btn').addEventListener('click', function(e) {
    // Here you would normally validate the cart
    // Then redirect to checkout
    window.location.href = 'checkout.html';
});