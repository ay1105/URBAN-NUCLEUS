INSERT INTO `travis scott_products` (name, price, image_url, description) VALUES
('AJ 1 Low x Travis Scott ''Fragment'' (UA)', 10499.00, 'https://4pfkicks.in/cdn/shop/files/29F95ED3-38D5-45A2-8D94-2F5F81B8971C.jpg', 'Limited edition AJ 1s with Fragment and Travis Scott collab.'),
('AJ 1 Low x Travis Scott ''Reverse Mocha'' (UA)', 9499.00, 'https://4pfkicks.in/cdn/shop/files/84C7B80B-77E9-4380-BB76-BD9BE42B809A.jpg', 'Reverse Mocha variant with signature backwards swoosh.'),
('Yeezy Boost 350v2 ''Blue tint'' (UA)', 3999.00, 'https://4pfkicks.in/cdn/shop/files/FB9E57C2-9434-4C02-930C-9086E30C6A5B.jpg', 'Iconic Yeezy Boost with blue tint styling.'),
('Retro 4 x Off-White ''Sail''', 3999.00, 'https://4pfkicks.in/cdn/shop/files/D93EE77D-EDFF-40C2-9EC1-46C975FBC740.jpg', 'Rare Off-White collab on Jordan Retro 4.');

SELECT * FROM `travis scott_products` ;