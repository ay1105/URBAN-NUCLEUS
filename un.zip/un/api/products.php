<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

class ProductAPI {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    // Get all products
    public function getProducts($category = null, $featured = null, $newArrivals = null) {
        try {
            $query = "SELECT p.*, c.name as category_name, 
                             GROUP_CONCAT(pi.image_url) as images,
                             GROUP_CONCAT(ps.size) as available_sizes
                      FROM products p 
                      LEFT JOIN categories c ON p.category_id = c.category_id
                      LEFT JOIN product_images pi ON p.product_id = pi.product_id
                      LEFT JOIN product_sizes ps ON p.product_id = ps.product_id
                      WHERE 1=1";
            
            $params = [];
            
            if ($category) {
                $query .= " AND c.name = ?";
                $params[] = $category;
            }
            
            if ($featured !== null) {
                $query .= " AND p.is_featured = ?";
                $params[] = $featured;
            }
            
            if ($newArrivals !== null) {
                $query .= " AND p.is_new_arrival = ?";
                $params[] = $newArrivals;
            }
            
            $query .= " GROUP BY p.product_id ORDER BY p.created_at DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            
            $products = $stmt->fetchAll();
            
            // Process images and sizes
            foreach ($products as &$product) {
                $product['images'] = $product['images'] ? explode(',', $product['images']) : [];
                $product['available_sizes'] = $product['available_sizes'] ? explode(',', $product['available_sizes']) : [];
            }
            
            return $products;
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // Get single product by ID
    public function getProduct($id) {
        try {
            $query = "SELECT p.*, c.name as category_name,
                             GROUP_CONCAT(pi.image_url) as images,
                             GROUP_CONCAT(ps.size) as available_sizes,
                             GROUP_CONCAT(ps.stock_quantity) as size_stocks
                      FROM products p 
                      LEFT JOIN categories c ON p.category_id = c.category_id
                      LEFT JOIN product_images pi ON p.product_id = pi.product_id
                      LEFT JOIN product_sizes ps ON p.product_id = ps.product_id
                      WHERE p.product_id = ?
                      GROUP BY p.product_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$id]);
            
            $product = $stmt->fetch();
            
            if ($product) {
                $product['images'] = $product['images'] ? explode(',', $product['images']) : [];
                $product['available_sizes'] = $product['available_sizes'] ? explode(',', $product['available_sizes']) : [];
                $product['size_stocks'] = $product['size_stocks'] ? explode(',', $product['size_stocks']) : [];
            }
            
            return $product;
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // Get categories
    public function getCategories() {
        try {
            $query = "SELECT * FROM categories WHERE is_active = 1 ORDER BY name";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
}

// Handle API requests
$api = new ProductAPI();

$method = $_SERVER['REQUEST_METHOD'];
$path = $_SERVER['REQUEST_URI'];
$pathParts = explode('/', trim($path, '/'));

switch ($method) {
    case 'GET':
        if (isset($pathParts[2]) && is_numeric($pathParts[2])) {
            // Get single product
            $result = $api->getProduct($pathParts[2]);
        } else {
            // Get all products with optional filters
            $category = $_GET['category'] ?? null;
            $featured = isset($_GET['featured']) ? ($_GET['featured'] === 'true') : null;
            $newArrivals = isset($_GET['new_arrivals']) ? ($_GET['new_arrivals'] === 'true') : null;
            
            if (isset($_GET['action']) && $_GET['action'] === 'categories') {
                $result = $api->getCategories();
            } else {
                $result = $api->getProducts($category, $featured, $newArrivals);
            }
        }
        break;
        
    default:
        $result = ['error' => 'Method not allowed'];
        http_response_code(405);
        break;
}

echo json_encode($result);
?> 