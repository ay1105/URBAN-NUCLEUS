<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

class AuthAPI {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    // User registration
    public function register($data) {
        try {
            // Check if email already exists
            $stmt = $this->conn->prepare("SELECT user_id FROM users WHERE email = ?");
            $stmt->execute([$data['email']]);
            
            if ($stmt->fetch()) {
                return ['error' => 'Email already registered'];
            }
            
            // Hash password
            $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
            
            $query = "INSERT INTO users (username, email, password_hash, first_name, last_name, phone) 
                      VALUES (?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                $data['username'],
                $data['email'],
                $password_hash,
                $data['first_name'],
                $data['last_name'],
                $data['phone'] ?? null
            ]);
            
            return ['success' => 'User registered successfully', 'user_id' => $this->conn->lastInsertId()];
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // User login
    public function login($email, $password) {
        try {
            $query = "SELECT user_id, username, email, password_hash, first_name, last_name, is_admin 
                      FROM users WHERE email = ?";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password_hash'])) {
                unset($user['password_hash']); // Don't send password hash
                return ['success' => 'Login successful', 'user' => $user];
            } else {
                return ['error' => 'Invalid email or password'];
            }
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // Add to cart
    public function addToCart($userId, $sessionId, $productId, $quantity, $size) {
        try {
            // Check if item already exists in cart
            $query = "SELECT cart_item_id, quantity FROM cart_items 
                      WHERE (user_id = ? OR session_id = ?) AND product_id = ? AND size = ?";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId, $sessionId, $productId, $size]);
            $existingItem = $stmt->fetch();
            
            if ($existingItem) {
                // Update quantity
                $newQuantity = $existingItem['quantity'] + $quantity;
                $query = "UPDATE cart_items SET quantity = ? WHERE cart_item_id = ?";
                $stmt = $this->conn->prepare($query);
                $stmt->execute([$newQuantity, $existingItem['cart_item_id']]);
            } else {
                // Add new item
                $query = "INSERT INTO cart_items (user_id, session_id, product_id, quantity, size) 
                          VALUES (?, ?, ?, ?, ?)";
                $stmt = $this->conn->prepare($query);
                $stmt->execute([$userId, $sessionId, $productId, $quantity, $size]);
            }
            
            return ['success' => 'Item added to cart'];
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // Get cart items
    public function getCart($userId, $sessionId) {
        try {
            $query = "SELECT ci.*, p.name, p.price, p.sale_price, pi.image_url 
                      FROM cart_items ci
                      JOIN products p ON ci.product_id = p.product_id
                      LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
                      WHERE ci.user_id = ? OR ci.session_id = ?";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId, $sessionId]);
            
            return $stmt->fetchAll();
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // Update cart item quantity
    public function updateCartItem($cartItemId, $quantity) {
        try {
            if ($quantity <= 0) {
                // Remove item
                $query = "DELETE FROM cart_items WHERE cart_item_id = ?";
            } else {
                // Update quantity
                $query = "UPDATE cart_items SET quantity = ? WHERE cart_item_id = ?";
            }
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$quantity, $cartItemId]);
            
            return ['success' => 'Cart updated'];
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // Newsletter subscription
    public function subscribeNewsletter($email) {
        try {
            // Check if already subscribed
            $stmt = $this->conn->prepare("SELECT subscriber_id FROM newsletter_subscribers WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                return ['error' => 'Email already subscribed'];
            }
            
            $query = "INSERT INTO newsletter_subscribers (email) VALUES (?)";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$email]);
            
            return ['success' => 'Successfully subscribed to newsletter'];
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
}

// Handle API requests
$api = new AuthAPI();
$input = json_decode(file_get_contents('php://input'), true);

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'POST':
        switch ($action) {
            case 'register':
                $result = $api->register($input);
                break;
                
            case 'login':
                $result = $api->login($input['email'], $input['password']);
                break;
                
            case 'add_to_cart':
                $result = $api->addToCart(
                    $input['user_id'] ?? null,
                    $input['session_id'] ?? null,
                    $input['product_id'],
                    $input['quantity'],
                    $input['size']
                );
                break;
                
            case 'subscribe_newsletter':
                $result = $api->subscribeNewsletter($input['email']);
                break;
                
            default:
                $result = ['error' => 'Invalid action'];
                break;
        }
        break;
        
    case 'GET':
        switch ($action) {
            case 'cart':
                $userId = $_GET['user_id'] ?? null;
                $sessionId = $_GET['session_id'] ?? null;
                $result = $api->getCart($userId, $sessionId);
                break;
                
            default:
                $result = ['error' => 'Invalid action'];
                break;
        }
        break;
        
    case 'PUT':
        if ($action === 'update_cart') {
            $result = $api->updateCartItem($input['cart_item_id'], $input['quantity']);
        } else {
            $result = ['error' => 'Invalid action'];
        }
        break;
        
    default:
        $result = ['error' => 'Method not allowed'];
        http_response_code(405);
        break;
}

echo json_encode($result);
?> 