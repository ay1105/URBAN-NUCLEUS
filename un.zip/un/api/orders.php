<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

class OrdersAPI {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    // Create new order
    public function createOrder($data) {
        try {
            $this->conn->beginTransaction();
            
            // Generate unique order number
            $orderNumber = 'UN-' . date('Ymd') . '-' . strtoupper(substr(md5(uniqid()), 0, 8));
            
            // Create order record
            $query = "INSERT INTO orders (user_id, order_number, total_amount, shipping_address, 
                                        billing_address, shipping_cost, tax_amount, payment_method, status) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')";
            
            $shippingAddress = $this->formatAddress($data['customer_info']);
            $billingAddress = $shippingAddress; // Same as shipping for now
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                $data['user_id'] ?? null,
                $orderNumber,
                $data['totals']['total'],
                $shippingAddress,
                $billingAddress,
                $data['totals']['shipping'],
                $data['totals']['tax'],
                $data['payment_method']
            ]);
            
            $orderId = $this->conn->lastInsertId();
            
            // Create order items
            foreach ($data['cart_items'] as $item) {
                $query = "INSERT INTO order_items (order_id, product_id, product_name, product_price, quantity, size) 
                          VALUES (?, ?, ?, ?, ?, ?)";
                
                $stmt = $this->conn->prepare($query);
                $stmt->execute([
                    $orderId,
                    $item['product_id'],
                    $item['name'],
                    $item['sale_price'] ?? $item['price'],
                    $item['quantity'],
                    $item['size']
                ]);
            }
            
            // Create user record if not exists (for guest orders)
            if (!$data['user_id']) {
                $userId = $this->createGuestUser($data['customer_info']);
                
                // Update order with user_id
                $query = "UPDATE orders SET user_id = ? WHERE order_id = ?";
                $stmt = $this->conn->prepare($query);
                $stmt->execute([$userId, $orderId]);
            }
            
            $this->conn->commit();
            
            return [
                'success' => 'Order created successfully',
                'order_number' => $orderNumber,
                'order_id' => $orderId
            ];
            
        } catch(PDOException $e) {
            $this->conn->rollback();
            return ['error' => $e->getMessage()];
        }
    }
    
    // Get orders for a user
    public function getOrders($userId) {
        try {
            $query = "SELECT o.*, COUNT(oi.order_item_id) as item_count 
                      FROM orders o 
                      LEFT JOIN order_items oi ON o.order_id = oi.order_id 
                      WHERE o.user_id = ? 
                      GROUP BY o.order_id 
                      ORDER BY o.created_at DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId]);
            
            return $stmt->fetchAll();
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // Get order details
    public function getOrderDetails($orderId) {
        try {
            // Get order info
            $query = "SELECT * FROM orders WHERE order_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$orderId]);
            $order = $stmt->fetch();
            
            if (!$order) {
                return ['error' => 'Order not found'];
            }
            
            // Get order items
            $query = "SELECT oi.*, p.name as product_name, pi.image_url 
                      FROM order_items oi 
                      JOIN products p ON oi.product_id = p.product_id 
                      LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
                      WHERE oi.order_id = ?";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$orderId]);
            $orderItems = $stmt->fetchAll();
            
            return [
                'order' => $order,
                'items' => $orderItems
            ];
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // Update order status
    public function updateOrderStatus($orderId, $status) {
        try {
            $query = "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$status, $orderId]);
            
            return ['success' => 'Order status updated'];
            
        } catch(PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    // Create guest user
    private function createGuestUser($customerInfo) {
        try {
            $query = "INSERT INTO users (username, email, first_name, last_name, phone, address, city, state, zip_code, country) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $username = 'guest_' . time() . '_' . rand(1000, 9999);
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                $username,
                $customerInfo['email'],
                $customerInfo['first_name'],
                $customerInfo['last_name'],
                $customerInfo['phone'],
                $customerInfo['address'],
                $customerInfo['city'],
                $customerInfo['state'],
                $customerInfo['zip_code'],
                $customerInfo['country']
            ]);
            
            return $this->conn->lastInsertId();
            
        } catch(PDOException $e) {
            return null;
        }
    }
    
    // Format address for database storage
    private function formatAddress($customerInfo) {
        return $customerInfo['address'] . "\n" . 
               $customerInfo['city'] . ", " . $customerInfo['state'] . " " . $customerInfo['zip_code'] . "\n" . 
               $customerInfo['country'];
    }
}

// Handle API requests
$api = new OrdersAPI();
$input = json_decode(file_get_contents('php://input'), true);

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'POST':
        switch ($action) {
            case 'create_order':
                $result = $api->createOrder($input);
                break;
                
            default:
                $result = ['error' => 'Invalid action'];
                break;
        }
        break;
        
    case 'GET':
        switch ($action) {
            case 'user_orders':
                $userId = $_GET['user_id'] ?? null;
                $result = $api->getOrders($userId);
                break;
                
            case 'order_details':
                $orderId = $_GET['order_id'] ?? null;
                $result = $api->getOrderDetails($orderId);
                break;
                
            default:
                $result = ['error' => 'Invalid action'];
                break;
        }
        break;
        
    case 'PUT':
        if ($action === 'update_status') {
            $orderId = $input['order_id'] ?? null;
            $status = $input['status'] ?? null;
            $result = $api->updateOrderStatus($orderId, $status);
        } else {
            $result = ['error' => 'Invalid action'];
        }
        break;
        
    default:
        $result = ['error' => 'Method not allowed'];
        http_response_code(405);
        break;
}

echo json_encode($result);
?> 