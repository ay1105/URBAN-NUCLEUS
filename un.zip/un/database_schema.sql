-- URBAN NUCLEUS Ecommerce Database Schema
-- MySQL Database for Fashion Ecommerce Website

-- Create database
CREATE DATABASE IF NOT EXISTS urban_nucleus_db;
USE urban_nucleus_db;

-- Users table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    city VARCHAR(50),
    state VARCHAR(50),
    zip_code VARCHAR(10),
    country VARCHAR(50) DEFAULT 'USA',
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    image_url VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    sale_price DECIMAL(10,2),
    category_id INT,
    brand VARCHAR(100),
    material VARCHAR(100),
    color VARCHAR(50),
    is_featured BOOLEAN DEFAULT FALSE,
    is_new_arrival BOOLEAN DEFAULT FALSE,
    is_on_sale BOOLEAN DEFAULT FALSE,
    stock_quantity INT DEFAULT 0,
    sku VARCHAR(50) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

-- Product images table
CREATE TABLE product_images (
    image_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    is_primary BOOLEAN DEFAULT FALSE,
    alt_text VARCHAR(200),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Product sizes table
CREATE TABLE product_sizes (
    size_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    size VARCHAR(10) NOT NULL,
    stock_quantity INT DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Orders table
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    shipping_address TEXT,
    billing_address TEXT,
    shipping_cost DECIMAL(10,2) DEFAULT 0.00,
    tax_amount DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    payment_method VARCHAR(50),
    tracking_number VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Order items table
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    product_price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL,
    size VARCHAR(10),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Shopping cart table
CREATE TABLE cart_items (
    cart_item_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    session_id VARCHAR(100),
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    size VARCHAR(10),
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Reviews table
CREATE TABLE reviews (
    review_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(200),
    comment TEXT,
    is_approved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Newsletter subscribers table
CREATE TABLE newsletter_subscribers (
    subscriber_id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample data

-- Categories
INSERT INTO categories (name, description) VALUES
('Summer Collection', 'Light and breezy summer wear'),
('Evening Wear', 'Elegant evening dresses and formal wear'),
('Accessories', 'Luxury bags, jewelry, and accessories'),
('New Arrivals', 'Latest fashion pieces');

-- Products
INSERT INTO products (name, description, price, category_id, brand, material, color, is_featured, is_new_arrival, stock_quantity, sku) VALUES
('Summer Silk Dress', 'Elegant silk dress perfect for summer evenings', 299.99, 1, 'Urban Nucleus', 'Silk', 'Coral', TRUE, TRUE, 50, 'UN-SSD-001'),
('Evening Gown', 'Stunning evening gown for special occasions', 599.99, 2, 'Urban Nucleus', 'Satin', 'Black', TRUE, FALSE, 25, 'UN-EG-001'),
('Luxury Leather Bag', 'Handcrafted leather bag with gold hardware', 199.99, 3, 'Urban Nucleus', 'Leather', 'Brown', FALSE, TRUE, 30, 'UN-LLB-001'),
('Linen Summer Blouse', 'Breathable linen blouse for casual elegance', 89.99, 1, 'Urban Nucleus', 'Linen', 'White', FALSE, FALSE, 75, 'UN-LSB-001'),
('Crystal Necklace', 'Elegant crystal necklace for any occasion', 149.99, 3, 'Urban Nucleus', 'Crystal', 'Clear', FALSE, TRUE, 40, 'UN-CN-001');

-- Product sizes
INSERT INTO product_sizes (product_id, size, stock_quantity) VALUES
(1, 'XS', 10), (1, 'S', 15), (1, 'M', 15), (1, 'L', 10),
(2, 'XS', 5), (2, 'S', 8), (2, 'M', 7), (2, 'L', 5),
(3, 'One Size', 30),
(4, 'XS', 20), (4, 'S', 25), (4, 'M', 20), (4, 'L', 10),
(5, 'One Size', 40);

-- Product images
INSERT INTO product_images (product_id, image_url, is_primary, alt_text) VALUES
(1, 'images/collections/summer-dress.jpg', TRUE, 'Summer Silk Dress'),
(2, 'images/collections/evening-gown.jpg', TRUE, 'Evening Gown'),
(3, 'images/collections/luxury-bags.jpg', TRUE, 'Luxury Leather Bag'),
(4, 'images/collections/linen-collection.jpg', TRUE, 'Linen Summer Blouse'),
(5, 'images/collections/crystal-necklace.jpg', TRUE, 'Crystal Necklace'); 