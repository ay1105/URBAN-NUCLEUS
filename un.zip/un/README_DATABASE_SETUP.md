# URBAN NUCLEUS Ecommerce Database Setup Guide

## Overview
This guide will help you implement a MySQL database for your URBAN NUCLEUS ecommerce website. The database will handle products, users, orders, cart management, and more.

## Prerequisites
1. **XAMPP/WAMP/MAMP** - Local web server with PHP and MySQL
2. **Basic knowledge of SQL** - You mentioned you have this
3. **Text editor** - VS Code, Sublime Text, etc.

## Step 1: Set Up Your Local Environment

### Install XAMPP (Recommended)
1. Download XAMPP from https://www.apachefriends.org/
2. Install and start Apache and MySQL services
3. Place your project files in the `htdocs` folder

### Alternative: Use WAMP or MAMP
- WAMP: https://www.wampserver.com/
- MAMP: https://www.mamp.info/

## Step 2: Create the Database

1. **Open phpMyAdmin**
   - Go to `http://localhost/phpmyadmin`
   - Or access through your local server's database management tool

2. **Import the Database Schema**
   - Click "Import" in phpMyAdmin
   - Select the `database_schema.sql` file
   - Click "Go" to create the database and tables

3. **Verify Database Creation**
   - You should see a database named `urban_nucleus_db`
   - It should contain tables: users, products, categories, orders, etc.

## Step 3: Configure Database Connection

1. **Edit Database Configuration**
   - Open `config/database.php`
   - Update the credentials if needed:
   ```php
   private $username = 'root';  // Your MySQL username
   private $password = '';      // Your MySQL password
   ```

2. **Test the Connection**
   - Create a test file `test_connection.php`:
   ```php
   <?php
   require_once 'config/database.php';
   $db = new Database();
   $conn = $db->getConnection();
   if ($conn) {
       echo "Database connection successful!";
   } else {
       echo "Database connection failed!";
   }
   ?>
   ```

## Step 4: Update Your HTML Files

### Add the products.js script to your HTML files:

**In collections.html:**
```html
<!-- Add this before closing </body> tag -->
<script src="products.js"></script>
```

**In index.html:**
```html
<!-- Add this before closing </body> tag -->
<script src="products.js"></script>
```

### Update your existing HTML to work with the database:

**Example: Update collections.html header section:**
```html
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collections - URBAN NUCLEUS</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="responsive.css">
    <link rel="stylesheet" href="collections.css">
    <!-- Add Font Awesome and other styles as needed -->
</head>
```

## Step 5: Test the Integration

1. **Start your local server** (Apache and MySQL)
2. **Navigate to your website** (e.g., `http://localhost/your-project-folder`)
3. **Check the browser console** for any JavaScript errors
4. **Test the API endpoints**:
   - `http://localhost/your-project-folder/api/products.php`
   - `http://localhost/your-project-folder/api/auth.php?action=categories`

## Database Structure Explained

### Core Tables:

1. **users** - Store customer accounts
   - user_id, username, email, password_hash, etc.

2. **products** - Store product information
   - product_id, name, price, description, category_id, etc.

3. **categories** - Product categories
   - category_id, name, description, etc.

4. **cart_items** - Shopping cart
   - cart_item_id, user_id, session_id, product_id, quantity, size

5. **orders** - Customer orders
   - order_id, user_id, total_amount, status, etc.

6. **order_items** - Individual items in orders
   - order_item_id, order_id, product_id, quantity, etc.

### Relationships:
- Products belong to Categories (foreign key: category_id)
- Cart items reference Products and Users
- Orders belong to Users
- Order items reference Orders and Products

## API Endpoints

### Products API (`api/products.php`):
- `GET /api/products.php` - Get all products
- `GET /api/products.php?category=Summer` - Filter by category
- `GET /api/products.php?featured=true` - Get featured products
- `GET /api/products.php?action=categories` - Get categories
- `GET /api/products.php/1` - Get single product

### Auth API (`api/auth.php`):
- `POST /api/auth.php?action=register` - User registration
- `POST /api/auth.php?action=login` - User login
- `POST /api/auth.php?action=add_to_cart` - Add to cart
- `GET /api/auth.php?action=cart` - Get cart items
- `PUT /api/auth.php?action=update_cart` - Update cart quantity

## Common Issues and Solutions

### 1. Database Connection Error
**Error:** "Connection error: SQLSTATE[HY000] [1045] Access denied"
**Solution:** Check your MySQL username and password in `config/database.php`

### 2. API Returns 404
**Error:** "File not found"
**Solution:** Make sure your files are in the correct directory structure and Apache is running

### 3. CORS Errors
**Error:** "Access to fetch at '...' from origin '...' has been blocked by CORS policy"
**Solution:** The API files already include CORS headers, but make sure you're accessing via a web server (not file://)

### 4. Products Not Loading
**Error:** "Error loading products"
**Solution:** Check browser console for specific error messages and verify database has data

## Adding More Features

### 1. User Authentication Pages
Create `login.html` and `signup.html` with forms that submit to the auth API.

### 2. Product Detail Pages
Create `product-detail.html` that loads product information by ID from the URL.

### 3. Checkout Process
Create checkout pages that handle order creation and payment processing.

### 4. Admin Panel
Create an admin interface to manage products, orders, and users.

## Security Considerations

1. **Password Hashing** - Already implemented using PHP's `password_hash()`
2. **SQL Injection Prevention** - Using prepared statements
3. **Input Validation** - Add more validation as needed
4. **HTTPS** - Use HTTPS in production

## Next Steps

1. **Add more products** to the database
2. **Create user registration/login pages**
3. **Implement checkout functionality**
4. **Add product search and filtering**
5. **Create an admin panel**
6. **Add payment processing**

## Testing Your Setup

1. **Test Database Connection:**
   ```php
   <?php
   require_once 'config/database.php';
   $db = new Database();
   $conn = $db->getConnection();
   echo $conn ? "Connected!" : "Failed!";
   ?>
   ```

2. **Test API Endpoints:**
   - Visit `http://localhost/your-project/api/products.php` in browser
   - Should return JSON data

3. **Test JavaScript Integration:**
   - Open browser console
   - Check for any JavaScript errors
   - Verify products are loading

## Support

If you encounter issues:
1. Check the browser console for JavaScript errors
2. Check the PHP error log
3. Verify database connection
4. Ensure all files are in the correct directory structure

The database is now integrated with your ecommerce website! Products will load from the database, cart functionality will persist data, and you can expand with user accounts and order management. 