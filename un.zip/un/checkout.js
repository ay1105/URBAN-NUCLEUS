// checkout.js - Checkout functionality with database integration
document.addEventListener('DOMContentLoaded', function() {
    let cartItems = [];
    let sessionId = localStorage.getItem('session_id') || generateSessionId();
    let userId = localStorage.getItem('user_id');
    
    // Generate session ID for guest users
    function generateSessionId() {
        const sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('session_id', sessionId);
        return sessionId;
    }
    
    // Load cart items from database
    async function loadCartItems() {
        try {
            const response = await fetch(`api/auth.php?action=cart&user_id=${userId || ''}&session_id=${sessionId}`);
            const data = await response.json();
            
            if (data.error) {
                console.error('Error loading cart:', data.error);
                return;
            }
            
            cartItems = data;
            displayCartItems();
            calculateTotals();
        } catch (error) {
            console.error('Error loading cart:', error);
        }
    }
    
    // Display cart items in order summary
    function displayCartItems() {
        const cartItemsContainer = document.getElementById('cartItems');
        
        if (cartItems.length === 0) {
            cartItemsContainer.innerHTML = '<p>Your cart is empty</p>';
            return;
        }
        
        let cartHTML = '';
        
        cartItems.forEach(item => {
            const price = item.sale_price || item.price;
            
            cartHTML += `
                <div class="cart-item">
                    <img src="${item.image_url || 'images/placeholder.jpg'}" alt="${item.name}">
                    <div class="cart-item-details">
                        <h4>${item.name}</h4>
                        <p>Size: ${item.size} | Qty: ${item.quantity}</p>
                        <p>$${price}</p>
                    </div>
                </div>
            `;
        });
        
        cartItemsContainer.innerHTML = cartHTML;
    }
    
    // Calculate order totals
    function calculateTotals() {
        let subtotal = 0;
        
        cartItems.forEach(item => {
            const price = item.sale_price || item.price;
            subtotal += price * item.quantity;
        });
        
        const shipping = subtotal > 100 ? 0 : 10; // Free shipping over $100
        const tax = subtotal * 0.08; // 8% tax
        const total = subtotal + shipping + tax;
        
        document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
        document.getElementById('shipping').textContent = `$${shipping.toFixed(2)}`;
        document.getElementById('tax').textContent = `$${tax.toFixed(2)}`;
        document.getElementById('total').textContent = `$${total.toFixed(2)}`;
        
        return {
            subtotal: subtotal,
            shipping: shipping,
            tax: tax,
            total: total
        };
    }
    
    // Handle form submission
    document.getElementById('checkoutForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        if (cartItems.length === 0) {
            showMessage('Your cart is empty. Please add items before placing an order.', 'error');
            return;
        }
        
        const placeOrderBtn = document.getElementById('placeOrderBtn');
        placeOrderBtn.disabled = true;
        placeOrderBtn.textContent = 'Processing...';
        
        try {
            // Get form data
            const formData = new FormData(this);
            const orderData = {
                customer_info: {
                    first_name: formData.get('firstName'),
                    last_name: formData.get('lastName'),
                    email: formData.get('email'),
                    phone: formData.get('phone'),
                    address: formData.get('address'),
                    city: formData.get('city'),
                    state: formData.get('state'),
                    zip_code: formData.get('zipCode'),
                    country: formData.get('country')
                },
                payment_method: formData.get('paymentMethod'),
                cart_items: cartItems,
                totals: calculateTotals(),
                user_id: userId,
                session_id: sessionId
            };
            
            // Send order to database
            const response = await fetch('api/orders.php?action=create_order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(orderData)
            });
            
            const result = await response.json();
            
            if (result.error) {
                showMessage('Error placing order: ' + result.error, 'error');
            } else {
                showMessage('Order placed successfully! Your order number is: ' + result.order_number, 'success');
                document.getElementById('orderNumber').textContent = result.order_number;
                
                // Clear cart after successful order
                await clearCart();
                
                // Disable form
                document.getElementById('checkoutForm').style.display = 'none';
            }
            
        } catch (error) {
            console.error('Error placing order:', error);
            showMessage('Error placing order. Please try again.', 'error');
        } finally {
            placeOrderBtn.disabled = false;
            placeOrderBtn.textContent = 'Place Order';
        }
    });
    
    // Clear cart after successful order
    async function clearCart() {
        try {
            // Clear cart items from database
            for (let item of cartItems) {
                await fetch('api/auth.php?action=update_cart', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        cart_item_id: item.cart_item_id,
                        quantity: 0
                    })
                });
            }
            
            // Clear localStorage cart count
            const cartCountElement = document.querySelector('.cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = '0';
            }
            
        } catch (error) {
            console.error('Error clearing cart:', error);
        }
    }
    
    // Show success/error messages
    function showMessage(message, type) {
        const successMessage = document.getElementById('successMessage');
        const errorMessage = document.getElementById('errorMessage');
        
        if (type === 'success') {
            successMessage.style.display = 'block';
            errorMessage.style.display = 'none';
            successMessage.querySelector('span').textContent = message;
        } else {
            errorMessage.style.display = 'block';
            successMessage.style.display = 'none';
            errorMessage.textContent = message;
        }
    }
    
    // Initialize checkout
    loadCartItems();
}); 