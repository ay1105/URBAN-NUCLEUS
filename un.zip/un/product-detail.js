// product-detail.js - Product Detail Page Functionality
document.addEventListener('DOMContentLoaded', function() {
    let currentProduct = null;
    let sessionId = localStorage.getItem('session_id') || generateSessionId();
    let userId = localStorage.getItem('user_id');

    // Generate session ID for guest users
    function generateSessionId() {
        const sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('session_id', sessionId);
        return sessionId;
    }

    // Get product ID from URL
    function getProductId() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('id');
    }

    // Load product details from database
    async function loadProductDetails() {
        const productId = getProductId();
        
        if (!productId) {
            showError('No product ID provided');
            return;
        }

        try {
            const response = await fetch(`api/products.php/${productId}`);
            const data = await response.json();

            if (data.error) {
                showError('Error loading product: ' + data.error);
                return;
            }

            if (!data || !data.product_id) {
                showError('Product not found');
                return;
            }

            currentProduct = data;
            displayProductDetails();
            loadRelatedProducts();

        } catch (error) {
            console.error('Error loading product:', error);
            showError('Error loading product details');
        }
    }

    // Display product details
    function displayProductDetails() {
        if (!currentProduct) return;

        // Hide loading, show product detail
        document.getElementById('loading').style.display = 'none';
        document.getElementById('product-detail').style.display = 'grid';
        document.getElementById('product-details').style.display = 'block';

        // Set product information
        document.getElementById('product-name').textContent = currentProduct.name;
        document.getElementById('product-category').textContent = currentProduct.category_name || 'Uncategorized';
        document.getElementById('product-description').textContent = currentProduct.description || 'No description available.';
        document.getElementById('full-description').textContent = currentProduct.description || 'No description available.';

        // Set price
        const currentPrice = currentProduct.sale_price || currentProduct.price;
        const originalPrice = currentProduct.sale_price ? currentProduct.price : null;

        document.getElementById('current-price').textContent = `$${currentPrice}`;
        
        if (originalPrice) {
            document.getElementById('original-price').textContent = `$${originalPrice}`;
            document.getElementById('original-price').style.display = 'inline';
        }

        // Set main image
        const mainImage = currentProduct.images && currentProduct.images.length > 0 
            ? currentProduct.images[0] 
            : 'images/placeholder.jpg';
        
        document.getElementById('main-image').src = mainImage;
        document.getElementById('main-image').alt = currentProduct.name;

        // Set thumbnails
        displayThumbnails();

        // Set size options
        displaySizeOptions();

        // Set specifications
        displaySpecifications();
    }

    // Display product thumbnails
    function displayThumbnails() {
        const thumbnailContainer = document.getElementById('thumbnail-images');
        const images = currentProduct.images || [];

        if (images.length <= 1) {
            thumbnailContainer.style.display = 'none';
            return;
        }

        let thumbnailHTML = '';
        images.forEach((image, index) => {
            const activeClass = index === 0 ? 'active' : '';
            thumbnailHTML += `
                <img src="${image}" alt="${currentProduct.name}" 
                     class="thumbnail ${activeClass}" 
                     onclick="changeMainImage('${image}', this)">
            `;
        });

        thumbnailContainer.innerHTML = thumbnailHTML;
    }

    // Display size options
    function displaySizeOptions() {
        const sizeSelect = document.getElementById('size-select');
        const sizes = currentProduct.available_sizes || [];

        if (sizes.length === 0) {
            sizeSelect.style.display = 'none';
            return;
        }

        let sizeHTML = '<option value="">Select Size</option>';
        sizes.forEach(size => {
            sizeHTML += `<option value="${size}">${size}</option>`;
        });

        sizeSelect.innerHTML = sizeHTML;
    }

    // Display product specifications
    function displaySpecifications() {
        const specsContainer = document.getElementById('specifications-content');
        
        const specs = [
            { label: 'Brand', value: currentProduct.brand || 'N/A' },
            { label: 'Material', value: currentProduct.material || 'N/A' },
            { label: 'Color', value: currentProduct.color || 'N/A' },
            { label: 'Category', value: currentProduct.category_name || 'N/A' },
            { label: 'SKU', value: currentProduct.sku || 'N/A' },
            { label: 'Stock', value: currentProduct.stock_quantity || '0' }
        ];

        let specsHTML = '';
        specs.forEach(spec => {
            specsHTML += `
                <div class="spec-item">
                    <div class="spec-label">${spec.label}</div>
                    <div class="spec-value">${spec.value}</div>
                </div>
            `;
        });

        specsContainer.innerHTML = specsHTML;
    }

    // Load related products
    async function loadRelatedProducts() {
        try {
            const response = await fetch('api/products.php?featured=true');
            const data = await response.json();

            if (data.error) {
                console.error('Error loading related products:', data.error);
                return;
            }

            // Filter out current product and limit to 4
            const relatedProducts = data
                .filter(product => product.product_id != currentProduct.product_id)
                .slice(0, 4);

            if (relatedProducts.length > 0) {
                displayRelatedProducts(relatedProducts);
            }

        } catch (error) {
            console.error('Error loading related products:', error);
        }
    }

    // Display related products
    function displayRelatedProducts(products) {
        const relatedContainer = document.getElementById('related-products');
        const relatedGrid = document.getElementById('related-grid');

        let relatedHTML = '';
        products.forEach(product => {
            const primaryImage = product.images && product.images.length > 0 
                ? product.images[0] 
                : 'images/placeholder.jpg';
            const price = product.sale_price || product.price;

            relatedHTML += `
                <div class="related-item">
                    <a href="product-detail.html?id=${product.product_id}">
                        <img src="${primaryImage}" alt="${product.name}">
                        <h3>${product.name}</h3>
                        <p class="price">$${price}</p>
                    </a>
                </div>
            `;
        });

        relatedGrid.innerHTML = relatedHTML;
        relatedContainer.style.display = 'block';
    }

    // Show error message
    function showError(message) {
        document.getElementById('loading').style.display = 'none';
        document.getElementById('error').textContent = message;
        document.getElementById('error').style.display = 'block';
    }

    // Change main image when thumbnail is clicked
    window.changeMainImage = function(imageSrc, thumbnailElement) {
        document.getElementById('main-image').src = imageSrc;
        
        // Update active thumbnail
        document.querySelectorAll('.thumbnail').forEach(thumb => {
            thumb.classList.remove('active');
        });
        thumbnailElement.classList.add('active');
    };

    // Change quantity
    window.changeQuantity = function(change) {
        const quantityInput = document.getElementById('quantity-input');
        let currentQuantity = parseInt(quantityInput.value) || 1;
        let newQuantity = currentQuantity + change;
        
        if (newQuantity < 1) newQuantity = 1;
        if (newQuantity > 99) newQuantity = 99;
        
        quantityInput.value = newQuantity;
    };

    // Add to cart functionality
    window.addToCart = async function() {
        if (!currentProduct) {
            alert('Product not loaded');
            return;
        }

        const sizeSelect = document.getElementById('size-select');
        const quantityInput = document.getElementById('quantity-input');
        
        const size = sizeSelect.value;
        const quantity = parseInt(quantityInput.value) || 1;

        if (!size && sizeSelect.style.display !== 'none') {
            alert('Please select a size');
            return;
        }

        if (quantity < 1) {
            alert('Please select a valid quantity');
            return;
        }

        try {
            const response = await fetch('api/auth.php?action=add_to_cart', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: userId,
                    session_id: sessionId,
                    product_id: currentProduct.product_id,
                    size: size || 'One Size',
                    quantity: quantity
                })
            });

            const data = await response.json();

            if (data.error) {
                alert('Error: ' + data.error);
            } else {
                alert('Item added to cart!');
                
                // Update cart count
                const cartCountElement = document.querySelector('.cart-count');
                if (cartCountElement) {
                    const currentCount = parseInt(cartCountElement.textContent) || 0;
                    cartCountElement.textContent = currentCount + quantity;
                }
            }

        } catch (error) {
            console.error('Error adding to cart:', error);
            alert('Error adding item to cart');
        }
    };

    // Show tab content
    window.showTab = function(tabName) {
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });

        // Remove active class from all tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        // Show selected tab content
        document.getElementById(tabName).classList.add('active');

        // Add active class to clicked button
        event.target.classList.add('active');
    };

    // Initialize product detail page
    loadProductDetails();
}); 