// cart.js - Shopping Cart Functionality with Database Integration
document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart
    let cart = [];
    let sessionId = localStorage.getItem('session_id') || generateSessionId();
    let userId = localStorage.getItem('user_id');
    
    // Generate session ID for guest users
    function generateSessionId() {
        const sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('session_id', sessionId);
        return sessionId;
    }
    
    // Load cart from database
    async function loadCart() {
        try {
            const response = await fetch(`api/auth.php?action=cart&user_id=${userId || ''}&session_id=${sessionId}`);
            const data = await response.json();
            
            if (data.error) {
                console.error('Error loading cart:', data.error);
                return;
            }
            
            cart = data;
            updateCartCount();
            updateCartDisplay();
            
            // Update cart dropdown if it exists
            const dropdown = document.getElementById('cart-dropdown');
            if (dropdown && dropdown.classList.contains('active')) {
                loadCartDropdown();
            }
        } catch (error) {
            console.error('Error loading cart:', error);
        }
    }
    
    // Add to cart functionality
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('add-to-cart')) {
            const productId = e.target.getAttribute('data-id');
            const sizeSelect = document.querySelector('.size-select');
            const quantityInput = document.querySelector('.quantity input');
            
            if (!sizeSelect || !quantityInput) {
                console.error('Size or quantity elements not found');
                return;
            }
            
            const size = sizeSelect.value;
            const quantity = parseInt(quantityInput.value) || 1;
            
            addToCart(productId, size, quantity);
        }
    });
    
    async function addToCart(productId, size, quantity) {
        try {
            const response = await fetch('api/auth.php?action=add_to_cart', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: userId,
                    session_id: sessionId,
                    product_id: productId,
                    size: size,
                    quantity: quantity
                })
            });
            
            const data = await response.json();
            
            if (data.error) {
                showCartNotification('Error: ' + data.error, 'error');
            } else {
                showCartNotification('Item added to cart!', 'success');
                loadCart(); // Reload cart from database
                
                // Update cart dropdown if it's open
                const dropdown = document.getElementById('cart-dropdown');
                if (dropdown && dropdown.classList.contains('active')) {
                    loadCartDropdown();
                }
            }
        } catch (error) {
            console.error('Error adding to cart:', error);
            showCartNotification('Error adding item to cart', 'error');
        }
    }
    
    function updateCartCount() {
        const count = cart.reduce((total, item) => total + item.quantity, 0);
        const cartCountElement = document.querySelector('.cart-count');
        if (cartCountElement) {
            cartCountElement.textContent = count;
        }
    }
    
    function updateCartDisplay() {
        const cartContainer = document.querySelector('.cart-items');
        if (!cartContainer) return;
        
        if (cart.length === 0) {
            cartContainer.innerHTML = '<p>Your cart is empty</p>';
            return;
        }
        
        let cartHTML = '';
        let total = 0;
        
        cart.forEach(item => {
            const price = item.sale_price || item.price;
            const itemTotal = price * item.quantity;
            total += itemTotal;
            
            cartHTML += `
                <div class="cart-item" data-id="${item.cart_item_id}">
                    <img src="${item.image_url}" alt="${item.name}">
                    <div class="cart-item-details">
                        <h4>${item.name}</h4>
                        <p>Size: ${item.size}</p>
                        <p>Price: $${price}</p>
                        <div class="quantity-controls">
                            <button class="quantity-btn minus" onclick="updateQuantity(${item.cart_item_id}, ${item.quantity - 1})">-</button>
                            <span>${item.quantity}</span>
                            <button class="quantity-btn plus" onclick="updateQuantity(${item.cart_item_id}, ${item.quantity + 1})">+</button>
                        </div>
                    </div>
                    <button class="remove-item" onclick="removeFromCart(${item.cart_item_id})">×</button>
                </div>
            `;
        });
        
        cartHTML += `
            <div class="cart-total">
                <h3>Total: $${total.toFixed(2)}</h3>
                <a href="checkout.html" class="checkout-btn" style="display: inline-block; padding: 10px 20px; background: #333; color: white; text-decoration: none; border-radius: 5px; margin-top: 10px;">Proceed to Checkout</a>
            </div>
        `;
        
        cartContainer.innerHTML = cartHTML;
    }
    
    // Global functions for cart operations
    window.updateQuantity = async function(cartItemId, newQuantity) {
        try {
            const response = await fetch('api/auth.php?action=update_cart', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    cart_item_id: cartItemId,
                    quantity: newQuantity
                })
            });
            
            const data = await response.json();
            
            if (data.error) {
                showCartNotification('Error: ' + data.error, 'error');
            } else {
                loadCart(); // Reload cart from database
            }
        } catch (error) {
            console.error('Error updating quantity:', error);
            showCartNotification('Error updating quantity', 'error');
        }
    };
    
    window.removeFromCart = function(cartItemId) {
        updateQuantity(cartItemId, 0);
    };
    
    function showCartNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `cart-notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    // Newsletter subscription
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const emailInput = this.querySelector('input[type="email"]');
            const email = emailInput.value.trim();
            
            if (validateEmail(email)) {
                try {
                    const response = await fetch('api/auth.php?action=subscribe_newsletter', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ email: email })
                    });
                    
                    const data = await response.json();
                    
                    if (data.error) {
                        alert('Error: ' + data.error);
                    } else {
                        alert('Thank you for subscribing!');
                        emailInput.value = '';
                    }
                } catch (error) {
                    console.error('Error subscribing:', error);
                    alert('Error subscribing to newsletter');
                }
            } else {
                alert('Please enter a valid email address');
            }
        });
    }
    
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // Cart dropdown functionality
    const cartIcon = document.querySelector('.cart-icon');
    if (cartIcon) {
        cartIcon.addEventListener('click', function(e) {
            e.preventDefault();
            toggleCartDropdown();
        });
    }

    // Create cart dropdown
    function createCartDropdown() {
        const dropdown = document.createElement('div');
        dropdown.className = 'cart-dropdown';
        dropdown.id = 'cart-dropdown';
        dropdown.innerHTML = `
            <div class="cart-dropdown-header">
                <h3>Shopping Cart</h3>
                <button class="close-cart" onclick="toggleCartDropdown()">×</button>
            </div>
            <div class="cart-dropdown-items" id="cart-dropdown-items">
                <!-- Cart items will be loaded here -->
            </div>
            <div class="cart-dropdown-footer">
                <div class="cart-total">
                    <span>Total:</span>
                    <span id="cart-dropdown-total">$0.00</span>
                </div>
                <a href="checkout.html" class="checkout-btn">Proceed to Checkout</a>
            </div>
        `;
        document.body.appendChild(dropdown);
    }

    // Toggle cart dropdown
    window.toggleCartDropdown = function() {
        const dropdown = document.getElementById('cart-dropdown');
        if (!dropdown) {
            createCartDropdown();
            loadCartDropdown();
        }
        
        dropdown.classList.toggle('active');
        
        if (dropdown.classList.contains('active')) {
            loadCartDropdown();
        }
    };

    // Load cart items in dropdown
    function loadCartDropdown() {
        const dropdownItems = document.getElementById('cart-dropdown-items');
        const dropdownTotal = document.getElementById('cart-dropdown-total');
        
        if (cart.length === 0) {
            dropdownItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
            dropdownTotal.textContent = '$0.00';
            return;
        }

        let cartHTML = '';
        let total = 0;

        cart.forEach(item => {
            const price = item.sale_price || item.price;
            const itemTotal = price * item.quantity;
            total += itemTotal;

            cartHTML += `
                <div class="cart-dropdown-item">
                    <img src="${item.image_url || 'images/placeholder.jpg'}" alt="${item.name}">
                    <div class="cart-dropdown-item-details">
                        <h4>${item.name}</h4>
                        <p>Size: ${item.size}</p>
                        <p>Qty: ${item.quantity}</p>
                        <p class="price">$${price}</p>
                    </div>
                    <button class="remove-dropdown-item" onclick="removeFromCart(${item.cart_item_id})">×</button>
                </div>
            `;
        });

        dropdownItems.innerHTML = cartHTML;
        dropdownTotal.textContent = `$${total.toFixed(2)}`;
    }

    // Close cart dropdown when clicking outside
    document.addEventListener('click', function(e) {
        const dropdown = document.getElementById('cart-dropdown');
        const cartIcon = document.querySelector('.cart-icon');
        
        if (dropdown && !dropdown.contains(e.target) && !cartIcon.contains(e.target)) {
            dropdown.classList.remove('active');
        }
    });

    // Initialize cart on page load
    loadCart();
});