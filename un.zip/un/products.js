// products.js - Product Loading and Display with Database Integration
document.addEventListener('DOMContentLoaded', function() {
    let products = [];
    let categories = [];
    
    // Load products from database
    async function loadProducts(filters = {}) {
        try {
            let url = 'api/products.php';
            const params = new URLSearchParams();
            
            if (filters.category) params.append('category', filters.category);
            if (filters.featured !== undefined) params.append('featured', filters.featured);
            if (filters.newArrivals !== undefined) params.append('new_arrivals', filters.newArrivals);
            
            if (params.toString()) {
                url += '?' + params.toString();
            }
            
            const response = await fetch(url);
            const data = await response.json();
            
            if (data.error) {
                console.error('Error loading products:', data.error);
                return;
            }
            
            products = data;
            displayProducts();
        } catch (error) {
            console.error('Error loading products:', error);
        }
    }
    
    // Load categories from database
    async function loadCategories() {
        try {
            const response = await fetch('api/products.php?action=categories');
            const data = await response.json();
            
            if (data.error) {
                console.error('Error loading categories:', data.error);
                return;
            }
            
            categories = data;
            displayCategories();
        } catch (error) {
            console.error('Error loading categories:', error);
        }
    }
    
    // Display products in the grid
    function displayProducts() {
        const productsContainer = document.querySelector('.collections-grid');
        if (!productsContainer) return;
        
        if (products.length === 0) {
            productsContainer.innerHTML = '<p>No products found</p>';
            return;
        }
        
        let productsHTML = '';
        
        products.forEach(product => {
            const primaryImage = product.images && product.images.length > 0 ? product.images[0] : 'images/placeholder.jpg';
            const price = product.sale_price || product.price;
            const categoryClass = product.category_name ? product.category_name.toLowerCase().replace(' ', '-') : '';
            
            productsHTML += `
                <div class="collection-item" data-category="${categoryClass} ${product.is_new_arrival ? 'new' : ''}">
                    <a href="product-detail.html?id=${product.product_id}">
                        <div class="collection-image">
                            <img src="${primaryImage}" alt="${product.name}">
                            <div class="collection-overlay">
                                <span>View Product</span>
                            </div>
                            ${product.is_new_arrival ? '<span class="new-badge">New</span>' : ''}
                            ${product.sale_price ? '<span class="sale-badge">Sale</span>' : ''}
                        </div>
                        <div class="collection-info">
                            <h3>${product.name}</h3>
                            <p class="price">
                                ${product.sale_price ? `<span class="original-price">$${product.price}</span>` : ''}
                                <span class="current-price">$${price}</span>
                            </p>
                            <p class="category">${product.category_name || 'Uncategorized'}</p>
                        </div>
                    </a>
                </div>
            `;
        });
        
        productsContainer.innerHTML = productsHTML;
    }
    
    // Display categories in filter buttons
    function displayCategories() {
        const filterContainer = document.querySelector('.filter-container');
        if (!filterContainer) return;
        
        let filterHTML = '<button class="filter-btn active" data-filter="all">All Collections</button>';
        
        categories.forEach(category => {
            const categorySlug = category.name.toLowerCase().replace(' ', '-');
            filterHTML += `<button class="filter-btn" data-filter="${categorySlug}">${category.name}</button>`;
        });
        
        // Add sort dropdown
        filterHTML += `
            <div class="sort-by">
                <label for="sort">Sort by:</label>
                <select id="sort" class="sort-select">
                    <option value="featured">Featured</option>
                    <option value="newest">Newest</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                </select>
            </div>
        `;
        
        filterContainer.innerHTML = filterHTML;
        
        // Add event listeners to filter buttons
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const filter = this.getAttribute('data-filter');
                filterProducts(filter);
            });
        });
        
        // Add event listener to sort dropdown
        const sortSelect = document.getElementById('sort');
        if (sortSelect) {
            sortSelect.addEventListener('change', function() {
                sortProducts(this.value);
            });
        }
    }
    
    // Filter products
    function filterProducts(filter) {
        const productItems = document.querySelectorAll('.collection-item');
        
        productItems.forEach(item => {
            if (filter === 'all' || item.getAttribute('data-category').includes(filter)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    // Sort products
    function sortProducts(sortBy) {
        const productItems = Array.from(document.querySelectorAll('.collection-item'));
        const productsContainer = document.querySelector('.collections-grid');
        
        productItems.sort((a, b) => {
            const priceA = parseFloat(a.querySelector('.current-price').textContent.replace('$', ''));
            const priceB = parseFloat(b.querySelector('.current-price').textContent.replace('$', ''));
            
            switch (sortBy) {
                case 'price-low':
                    return priceA - priceB;
                case 'price-high':
                    return priceB - priceA;
                case 'newest':
                    // Sort by new arrivals first
                    const aIsNew = a.getAttribute('data-category').includes('new');
                    const bIsNew = b.getAttribute('data-category').includes('new');
                    if (aIsNew && !bIsNew) return -1;
                    if (!aIsNew && bIsNew) return 1;
                    return 0;
                default:
                    return 0;
            }
        });
        
        // Reorder DOM elements
        productItems.forEach(item => productsContainer.appendChild(item));
    }
    
    // Load featured products for homepage
    async function loadFeaturedProducts() {
        try {
            const response = await fetch('api/products.php?featured=true');
            const data = await response.json();
            
            if (data.error) {
                console.error('Error loading featured products:', data.error);
                return;
            }
            
            displayFeaturedProducts(data);
        } catch (error) {
            console.error('Error loading featured products:', error);
        }
    }
    
    // Display featured products on homepage
    function displayFeaturedProducts(featuredProducts) {
        const featuredContainer = document.querySelector('.featured-products');
        if (!featuredContainer || featuredProducts.length === 0) return;
        
        let featuredHTML = '';
        
        featuredProducts.slice(0, 4).forEach(product => {
            const primaryImage = product.images && product.images.length > 0 ? product.images[0] : 'images/placeholder.jpg';
            const price = product.sale_price || product.price;
            
            featuredHTML += `
                <div class="featured-product">
                    <div class="product-image">
                        <img src="${primaryImage}" alt="${product.name}">
                        ${product.is_new_arrival ? '<span class="new-badge">New</span>' : ''}
                        ${product.sale_price ? '<span class="sale-badge">Sale</span>' : ''}
                    </div>
                    <div class="product-info">
                        <h3>${product.name}</h3>
                        <p class="price">
                            ${product.sale_price ? `<span class="original-price">$${product.price}</span>` : ''}
                            <span class="current-price">$${price}</span>
                        </p>
                        <button class="add-to-cart" data-id="${product.product_id}">Add to Cart</button>
                    </div>
                </div>
            `;
        });
        
        featuredContainer.innerHTML = featuredHTML;
    }
    
    // Initialize based on current page
    const currentPage = window.location.pathname;
    
    if (currentPage.includes('collections.html')) {
        loadProducts();
        loadCategories();
    } else if (currentPage.includes('index.html') || currentPage === '/') {
        loadFeaturedProducts();
    }
}); 