# URBAN NUCLEUS Ecommerce Installation Guide

## 🚀 **Complete Installation Guide for New Users**

### **Prerequisites**
1. **XAMPP** (or WAMP/MAMP) - Download from https://www.apachefriends.org/
2. **Basic computer knowledge**
3. **Text editor** (Notepad++, VS Code, etc.)

---

## **Step 1: Install XAMPP**

1. **Download XAMPP** from https://www.apachefriends.org/
2. **Install XAMPP** on your computer
3. **Start XAMPP Control Panel**
4. **Start Apache and MySQL** services

---

## **Step 2: Set Up Project Files**

1. **Navigate to XAMPP folder:**
   - Windows: `C:\xampp\htdocs\`
   - Mac: `/Applications/XAMPP/htdocs/`
   - Linux: `/opt/lampp/htdocs/`

2. **Create project folder:**
   ```
   C:\xampp\htdocs\urban-nucleus\
   ```

3. **Copy all project files** into this folder:
   - All HTML files
   - All CSS files  
   - All JavaScript files
   - `config/` folder
   - `api/` folder
   - `database_schema.sql`
   - `test_connection.php`

---

## **Step 3: Create Database**

1. **Open phpMyAdmin:**
   - Go to: `http://localhost/phpmyadmin`

2. **Import Database:**
   - Click "Import" tab
   - Choose file: `database_schema.sql`
   - Click "Go"

3. **Verify Database:**
   - You should see `urban_nucleus_db` in the left sidebar
   - It should contain all tables: users, products, orders, etc.

---

## **Step 4: Test Installation**

1. **Test Database Connection:**
   - Go to: `http://localhost/urban-nucleus/test_connection.php`
   - Should show: "Database connection successful!"

2. **Test Website:**
   - Go to: `http://localhost/urban-nucleus/`
   - Should load the homepage

3. **Test API:**
   - Go to: `http://localhost/urban-nucleus/api/products.php`
   - Should return JSON data

---

## **Step 5: Customize for Your Business**

### **Update Business Information**
1. **Edit `index.html`** - Change "URBAN NUCLEUS" to your brand name
2. **Update product images** - Replace with your own product photos
3. **Modify colors** - Edit `style.css` to match your brand colors

### **Add Your Products**
1. **Go to phpMyAdmin**
2. **Click on `urban_nucleus_db`**
3. **Click on `products` table**
4. **Click "Insert"** to add your products

### **Update Database Configuration**
1. **Open `config/database.php`**
2. **Update credentials** if needed:
   ```php
   private $username = 'root';  // Your MySQL username
   private $password = '';      // Your MySQL password
   ```

---

## **Step 6: Test Complete Functionality**

### **Test Shopping Cart:**
1. **Go to collections page**
2. **Add items to cart**
3. **Check cart count updates**

### **Test Checkout:**
1. **Add items to cart**
2. **Go to checkout page**
3. **Fill out form and place order**
4. **Check database** for new order

### **Test Database Integration:**
1. **Check orders table** in phpMyAdmin
2. **Verify order items** are saved
3. **Check user accounts** are created

---

## **Troubleshooting**

### **Common Issues:**

#### **1. Database Connection Error**
- **Solution:** Check XAMPP is running (Apache + MySQL)
- **Solution:** Verify database credentials in `config/database.php`

#### **2. 404 Errors**
- **Solution:** Ensure files are in correct folder: `htdocs/urban-nucleus/`
- **Solution:** Check Apache is running

#### **3. API Not Working**
- **Solution:** Access via `http://localhost/` not `file://`
- **Solution:** Check browser console for JavaScript errors

#### **4. Images Not Loading**
- **Solution:** Add your own product images
- **Solution:** Update image paths in HTML files

---

## **Customization Options**

### **Change Brand Name:**
1. **Search and replace** "URBAN NUCLEUS" in all HTML files
2. **Update logo** and branding elements

### **Change Colors:**
1. **Edit `style.css`** - Modify color variables
2. **Update button colors** and backgrounds

### **Add More Products:**
1. **Use phpMyAdmin** to add products
2. **Or edit `database_schema.sql`** to include your products

### **Modify Shipping/Tax:**
1. **Edit `checkout.js`** - Change shipping and tax calculations
2. **Update business logic** as needed

---

## **Security Considerations**

### **For Production Use:**
1. **Change default passwords**
2. **Use HTTPS** in production
3. **Regular database backups**
4. **Update PHP and MySQL** regularly

### **Admin Access:**
1. **Create admin user** in database
2. **Set up admin panel** for order management
3. **Secure admin pages** with authentication

---

## **Support**

### **If You Need Help:**
1. **Check browser console** (F12) for errors
2. **Check XAMPP error logs**
3. **Verify database connection**
4. **Ensure all files are in correct locations**

### **Getting Started:**
1. **Follow this guide step by step**
2. **Test each component** before moving to next step
3. **Customize gradually** - don't change everything at once

---

## **Next Steps After Installation**

1. **Add your products** to the database
2. **Customize the design** to match your brand
3. **Set up payment processing** (Stripe, PayPal, etc.)
4. **Create admin panel** for order management
5. **Add user registration** and login system
6. **Set up email notifications** for orders
7. **Add product reviews** and ratings
8. **Implement search** and advanced filtering

---

## **Complete System Features**

✅ **Product Management** - Add, edit, categorize products
✅ **Shopping Cart** - Add items, update quantities
✅ **Checkout System** - Complete order processing
✅ **User Management** - Guest and registered users
✅ **Order Management** - Track orders and status
✅ **Database Integration** - All data stored in MySQL
✅ **Responsive Design** - Works on all devices
✅ **Modern UI/UX** - Professional ecommerce interface

---

**Your ecommerce website is now ready to use!** 🎉

Start by adding your products and customizing the design to match your brand. 