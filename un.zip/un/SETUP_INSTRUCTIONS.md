# 🛍️ Ecommerce Website Setup Guide

## 📋 Prerequisites

### 1. Install XAMPP
- Download XAMPP from: https://www.apachefriends.org/
- Install it on your computer
- Start Apache and MySQL services

### 2. System Requirements
- Windows 10/11 (or Mac/Linux with XAMPP)
- At least 2GB RAM
- 500MB free disk space

## 🚀 Quick Setup (5 Minutes)

### Step 1: Extract Files
1. **Extract the ZIP file** to your desktop
2. **Copy the entire folder** to `C:\xampp\htdocs\`
3. **Rename the folder** to something simple like `ecommerce`

### Step 2: Start XAMPP
1. **Open XAMPP Control Panel**
2. **Click "Start"** for Apache
3. **Click "Start"** for MySQL
4. **Both should show green** status

### Step 3: Create Database
1. **Open your browser**
2. **Go to:** `http://localhost/phpmyadmin`
3. **Click "New"** to create a new database
4. **Name it:** `urban_nucleus_db`
5. **Click "Create"**

### Step 4: Import Database
1. **Select the database** you just created
2. **Click "Import"** tab
3. **Click "Choose File"**
4. **Select:** `database_schema_clean.sql`
5. **Click "Go"** at the bottom

### Step 5: Update Database Connection
1. **Open:** `config/database.php`
2. **Update these lines:**
   ```php
   $host = 'localhost';
   $dbname = 'urban_nucleus_db';
   $username = 'root';
   $password = '';  // Leave empty for XAMPP default
   ```

### Step 6: Test the Website
1. **Open your browser**
2. **Go to:** `http://localhost/ecommerce/`
3. **You should see the homepage!**

## 🧪 Testing All Features

### Test 1: Browse Products
- ✅ Go to Collections page
- ✅ Click on products
- ✅ View product details

### Test 2: Shopping Cart
- ✅ Add items to cart
- ✅ Click cart icon (dropdown should appear)
- ✅ Remove items from cart
- ✅ Check cart count updates

### Test 3: Checkout Process
- ✅ Add items to cart
- ✅ Click "Proceed to Checkout"
- ✅ Fill out the form
- ✅ Place order
- ✅ Check database for order

### Test 4: Database Verification
1. **Go to:** `http://localhost/phpmyadmin`
2. **Select:** `urban_nucleus_db`
3. **Check these tables:**
   - `orders` - Should show your orders
   - `order_items` - Should show order details
   - `users` - Should show guest users

## 🔧 Troubleshooting

### Problem: "Page Not Found"
**Solution:**
- Make sure files are in `C:\xampp\htdocs\ecommerce\`
- Check Apache is running (green in XAMPP)
- Try: `http://localhost/ecommerce/`

### Problem: "Database Connection Failed"
**Solution:**
- Check MySQL is running (green in XAMPP)
- Verify database name in `config/database.php`
- Make sure database exists in phpMyAdmin

### Problem: "Cart Not Working"
**Solution:**
- Check browser console for errors (F12)
- Make sure all files are in the correct folders
- Verify API files are accessible

### Problem: "Images Not Loading"
**Solution:**
- This is normal - images are placeholders
- Add your own images to `images/` folder
- Update image paths in database if needed

## 📁 File Structure (What's Included)

```
ecommerce/
├── index.html              # Homepage
├── collections.html        # Products page
├── about.html             # About page
├── checkout.html          # Checkout page
├── product-detail.html    # Product detail page
├── style.css              # Main styles
├── responsive.css         # Mobile styles
├── cart.js               # Cart functionality
├── products.js           # Product loading
├── checkout.js           # Checkout process
├── product-detail.js     # Product details
├── main.js               # Main JavaScript
├── about.js              # About page JS
├── collections.js        # Collections page JS
├── config/
│   └── database.php      # Database connection
├── api/
│   ├── products.php      # Product API
│   ├── auth.php          # Cart & user API
│   └── orders.php        # Order API
├── database_schema_clean.sql  # Database structure
├── SETUP_INSTRUCTIONS.md      # This file
└── INSTALLATION_GUIDE.md     # Detailed guide
```

## 🎯 What You Can Do

### ✅ Fully Functional Features:
- **Browse products** and categories
- **Add items to cart** with size/quantity
- **View cart dropdown** with items
- **Remove items** from cart
- **Proceed to checkout**
- **Place orders** (saved to database)
- **View order history** in database
- **Responsive design** (mobile-friendly)

### 🔧 Customizable Features:
- **Add your own products** to database
- **Change website colors** in style.css
- **Add your own images** to images/ folder
- **Modify product details** in database
- **Add payment processing** (requires additional setup)

## 🆘 Need Help?

### Common Issues:
1. **XAMPP not starting** - Check if other services are using ports 80/3306
2. **Database errors** - Make sure MySQL is running
3. **Page not loading** - Check file paths and Apache status
4. **Cart not working** - Check browser console for JavaScript errors

### Getting Support:
- Check the browser console (F12) for error messages
- Verify all files are in the correct locations
- Make sure XAMPP services are running
- Test database connection in phpMyAdmin

## 🎉 Success!

Once everything is working, you'll have a fully functional ecommerce website with:
- ✅ Product browsing
- ✅ Shopping cart
- ✅ Checkout process
- ✅ Order management
- ✅ Database storage
- ✅ Responsive design

**Enjoy your new ecommerce website!** 🛍️✨ 