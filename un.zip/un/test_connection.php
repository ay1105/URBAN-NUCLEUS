<?php
// Test database connection
require_once 'config/database.php';

echo "<h2>Database Connection Test</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    if ($conn) {
        echo "<p style='color: green;'>✅ Database connection successful!</p>";
        
        // Test query to get product count
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM products");
        $stmt->execute();
        $result = $stmt->fetch();
        
        echo "<p>📦 Products in database: " . $result['count'] . "</p>";
        
        // Test query to get category count
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM categories");
        $stmt->execute();
        $result = $stmt->fetch();
        
        echo "<p>📂 Categories in database: " . $result['count'] . "</p>";
        
        // Show sample products
        $stmt = $conn->prepare("SELECT name, price FROM products LIMIT 3");
        $stmt->execute();
        $products = $stmt->fetchAll();
        
        if ($products) {
            echo "<h3>Sample Products:</h3>";
            echo "<ul>";
            foreach ($products as $product) {
                echo "<li>{$product['name']} - \${$product['price']}</li>";
            }
            echo "</ul>";
        }
        
    } else {
        echo "<p style='color: red;'>❌ Database connection failed!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Please check your database configuration in config/database.php</p>";
}

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>If connection is successful, you can now use your website with the database</li>";
echo "<li>Add the products.js script to your HTML files</li>";
echo "<li>Test the API endpoints in your browser</li>";
echo "<li>Check the browser console for any JavaScript errors</li>";
echo "</ol>";
?> 